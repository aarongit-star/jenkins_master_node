# License 

Copyright (C) 2019, George Smith - All Rights Reserved  
Unauthorized copying of contents of this repository, via any medium, is strictly prohibited.  

The repository is made public for the purposes of code reviews performed by potential employers.  

Proprietary content.  

Written by George Smith , November 2019
