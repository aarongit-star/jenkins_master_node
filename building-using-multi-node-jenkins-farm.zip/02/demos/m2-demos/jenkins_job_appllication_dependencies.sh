yum update -y
yum install git  -y
yum install maven  -y
