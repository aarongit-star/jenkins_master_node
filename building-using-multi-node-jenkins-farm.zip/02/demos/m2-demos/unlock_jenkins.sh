
sudo cat /var/lib/jenkins/secrets/initialAdminPassword