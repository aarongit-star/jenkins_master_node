# Generate SSH keys but skip all prompts except for file name
ssh-keygen -t rsa -N ""